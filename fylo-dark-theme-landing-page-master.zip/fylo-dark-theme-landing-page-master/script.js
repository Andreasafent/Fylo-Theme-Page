const getStartedBtn = document.querySelector('.get-started-btn-footer');
const emailInput = document.querySelector('#email-area');
const errorElement = document.querySelector('.error');

getStartedBtn.addEventListener('click', ()=>{
    if(emailInput.ariaValueMax.length==0){
        errorElement.textContent='Please enter a valid email address';
    }
})